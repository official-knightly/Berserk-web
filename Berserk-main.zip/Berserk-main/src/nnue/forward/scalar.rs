use crate::{
    nnue::{
        Aligned, DEQUANT_MULTIPLIER, FT_QUANT, FT_SHIFT, L1_SIZE, L2_SIZE, L3_SIZE, Parameters, SparseEntry,
        accumulator::{PstAccumulator, ThreatAccumulator},
    },
    types::Color,
};

pub fn activate_ft(pst: &PstAccumulator, threat: &ThreatAccumulator, stm: Color) -> Aligned<[u8; L1_SIZE]> {
    let mut output = Aligned::new([0; L1_SIZE]);

    for flip in [0, 1] {
        let pst_input = &pst.values[stm as usize ^ flip];
        let threat_input = &threat.values[stm as usize ^ flip];

        for i in 0..L1_SIZE / 2 {
            let left = (pst_input[i] + threat_input[i]).clamp(0, FT_QUANT as i16);
            let right = (pst_input[i + L1_SIZE / 2] + threat_input[i + L1_SIZE / 2]).clamp(0, FT_QUANT as i16);

            output[i + flip * L1_SIZE / 2] = ((left as i32 * right as i32) >> FT_SHIFT) as u8;
        }
    }

    output
}

pub unsafe fn propagate_l1(
    ft_out: &Aligned<[u8; L1_SIZE]>, nnz: &[u16], bucket: usize, parameters: &Parameters,
) -> Aligned<[f32; L2_SIZE]> {
    const CHUNKS: usize = 4;

    let mut pre_activations = [0i32; L2_SIZE];

    let packed = std::slice::from_raw_parts(ft_out.as_ptr() as *const i32, L1_SIZE / CHUNKS);

    for i in 0..nnz.len() {
        let index = *nnz.get_unchecked(i) as usize;
        let input = packed.get_unchecked(index);
        let weights = &parameters.l1_weights[bucket][index * L2_SIZE * CHUNKS..];

        for j in 0..L2_SIZE {
            let mut vector = 0;

            for k in 0..CHUNKS {
                let byte = (input >> (k * 8)) & 0xFF;
                let weight = weights[j * CHUNKS + k];

                vector += (byte as i16) * (weight as i16);
            }

            pre_activations[j] += vector as i32;
        }
    }

    let mut output = Aligned::new([0.0; L2_SIZE]);

    for i in 0..L2_SIZE {
        // Starting from here, we move into float space, so order of operations is critical for staying semantically
        // identical to the vectorized inference. In particular, using FMA instead of separate mul+add matters here and below.
        output[i] =
            (pre_activations[i] as f32).mul_add(DEQUANT_MULTIPLIER, parameters.l1_biases[bucket][i]).clamp(0.0, 1.0);
    }

    output
}

pub fn propagate_l2(
    l1_out: &Aligned<[f32; L2_SIZE]>, bucket: usize, parameters: &Parameters,
) -> Aligned<[f32; L3_SIZE]> {
    // Note: It is important that we initialize the accumulator to the biases, and don't add the biases
    // afterward, to preserve the same order of operations as the vector implementation.
    let mut output = Aligned::new(parameters.l2_biases[bucket]);

    for i in 0..L2_SIZE {
        for j in 0..L3_SIZE {
            output[j] = parameters.l2_weights[bucket][i][j].mul_add(l1_out[i], output[j]);
        }
    }

    for i in 0..L3_SIZE {
        output[i] = output[i].clamp(0.0, 1.0);
    }
    output
}

pub fn propagate_l3(l2_out: &Aligned<[f32; L3_SIZE]>, bucket: usize, parameters: &Parameters) -> f32 {
    // For cross platform compatibility, we always sum-reduce into a 16-element "vector", and then horizontally reduce that.
    const LANES: usize = 16;

    let mut sums = [0.0; LANES];
    for i in (0..L3_SIZE).step_by(LANES) {
        for j in 0..LANES {
            sums[j] = parameters.l3_weights[bucket][i + j].mul_add(l2_out[i + j], sums[j]);
        }
    }

    // We do the horizontal reduction via recursive halving, as that's what `_mm512_reduce_add_ps` does. Any other SIMD
    // implementation (e.g. NEON) must ensure the same order of operations.
    let mut stride = LANES / 2;
    while stride > 0 {
        for i in 0..stride {
            sums[i] += sums[i + stride];
        }
        stride /= 2;
    }

    sums[0] + parameters.l3_biases[bucket]
}

pub unsafe fn find_nnz(ft_out: &Aligned<[u8; L1_SIZE]>, _: &[SparseEntry]) -> (Aligned<[u16; L1_SIZE / 4]>, usize) {
    let mut indexes = Aligned::new([0; L1_SIZE / 4]);
    let mut count = 0;

    for i in 0..L1_SIZE / 4 {
        let mut nonzero = 0;

        for j in 0..4 {
            nonzero |= ft_out[i * 4 + j];
        }

        if nonzero != 0 {
            indexes[count] = i as u16;
            count += 1;
        }
    }

    (indexes, count)
}