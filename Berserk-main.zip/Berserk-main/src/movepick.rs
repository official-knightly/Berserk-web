use crate::{
    lookup::king_attacks,
    search::NodeType,
    setwise::{bishop_attacks_setwise, knight_attacks_setwise, pawn_attacks_setwise, rook_attacks_setwise},
    thread::ThreadData,
    types::{ArrayVec, Bitboard, MAX_MOVES, Move, MoveEntry, MoveList, PieceType},
};

#[derive(Copy, Clone, Eq, PartialEq, PartialOrd)]
pub enum Stage {
    HashMove,
    GenerateNoisy,
    GoodNoisy,
    Quiet,
    BadNoisy,
}

pub struct MovePicker {
    list: MoveList,
    tt_move: Move,
    threshold: Option<i32>,
    stage: Stage,
    bad_noisy: ArrayVec<Move, MAX_MOVES>,
    bad_noisy_idx: usize,
    noisy_count: usize,
}

impl MovePicker {
    pub const fn new(tt_move: Move, threshold: Option<i32>) -> Self {
        Self {
            list: MoveList::new(),
            tt_move,
            threshold,
            stage: if tt_move.is_present() { Stage::HashMove } else { Stage::GenerateNoisy },
            bad_noisy: ArrayVec::new(),
            bad_noisy_idx: 0,
            noisy_count: 0,
        }
    }

    pub const fn stage(&self) -> Stage {
        self.stage
    }

    pub fn next<NODE: NodeType>(&mut self, td: &ThreadData, skip_quiets: bool, ply: isize) -> Option<Move> {
        if self.stage == Stage::HashMove {
            self.stage = Stage::GenerateNoisy;

            if td.board.is_legal(self.tt_move) {
                return Some(self.tt_move);
            }
        }

        if self.stage == Stage::GenerateNoisy {
            self.stage = Stage::GoodNoisy;
            td.board.append_noisy_moves(&mut self.list);
            self.remove_tt();
            self.score_noisy(td);
        }

        if self.stage == Stage::GoodNoisy {
            while !self.list.is_empty() {
                let entry = self.get_best_entry();
                let threshold = self.threshold.unwrap_or_else(|| {
                    if self.tt_move.is_quiet() && self.noisy_count > 2 { 1 } else { -entry.score / 47 + 116 }
                });
                if !td.board.see(entry.mv, threshold) {
                    self.bad_noisy.push(entry.mv);
                    continue;
                }

                if NODE::ROOT {
                    self.score_noisy(td);
                }

                self.noisy_count += 1;
                return Some(entry.mv);
            }

            if skip_quiets {
                self.stage = Stage::BadNoisy;
            } else {
                self.stage = Stage::Quiet;
                td.board.append_quiet_moves(&mut self.list);
                self.remove_tt();
                self.score_quiet(td, ply);
            }
        }

        if self.stage == Stage::Quiet {
            if !skip_quiets && !self.list.is_empty() {
                if NODE::ROOT {
                    self.score_quiet(td, ply);
                }
                return Some(self.get_best_entry().mv);
            }

            self.stage = Stage::BadNoisy;
        }

        // Stage::BadNoisy
        if self.bad_noisy_idx < self.bad_noisy.len() {
            let mv = self.bad_noisy[self.bad_noisy_idx];
            self.bad_noisy_idx += 1;
            return Some(mv);
        }

        None
    }

    fn get_best_entry(&mut self) -> MoveEntry {
        let mut best_index = 0;
        let mut best_score = i32::MIN;

        for (index, entry) in self.list.iter().enumerate() {
            if entry.score >= best_score {
                best_index = index;
                best_score = entry.score;
            }
        }
        self.list.remove(best_index)
    }

    fn remove_tt(&mut self) {
        if let Some(pos) = self.list.iter().position(|&e| e.mv == self.tt_move) {
            self.list.remove(pos);
        }
    }

    fn score_noisy(&mut self, td: &ThreadData) {
        let threats = td.board.all_threats();

        for entry in self.list.iter_mut() {
            let mv = entry.mv;
            let captured = td.board.type_on(mv.capture_sq());
            let pt = td.board.type_on(mv.from());

            entry.score = 14232 * captured.value() / 1024
                + td.noisy_history.get(threats, td.board.moved_piece(mv), mv.to(), captured)
                + 4558 * (mv.is_promotion() && mv.promo_piece_type() == PieceType::Queen) as i32
                + (200000 - 20000 * pt as i32) * td.board.in_check() as i32;
        }
    }

    fn score_quiet(&mut self, td: &ThreadData, ply: isize) {
        let threats = td.board.all_threats();
        let side = td.board.side_to_move();
        let pawn_key = td.board.pawn_key();
        let occupancies = td.board.occupancies();
        let pawn_threats = td.board.piece_threats(PieceType::Pawn);

        let non_pawn_threats = td.board.piece_threats(PieceType::Knight)
            | td.board.piece_threats(PieceType::Bishop)
            | td.board.piece_threats(PieceType::Rook)
            | td.board.piece_threats(PieceType::Queen)
            | td.board.piece_threats(PieceType::King);

        let threatened = {
            let minor_threats =
                pawn_threats | td.board.piece_threats(PieceType::Knight) | td.board.piece_threats(PieceType::Bishop);
            let rook_threats = minor_threats | td.board.piece_threats(PieceType::Rook);
            [Bitboard(0), pawn_threats, pawn_threats, minor_threats, rook_threats, Bitboard(0)]
        };

        let escape = [0, 8854, 8170, 14051, 20357, 0];

        // safe squares where we can attack an opponent piece
        let offense = {
            let knight_vulnerable = (td.board.colored_pieces(!side, PieceType::Bishop) & !threats)
                | td.board.colored_pieces(!side, PieceType::Rook)
                | td.board.colored_pieces(!side, PieceType::Queen);
            let bishop_vulnerable = td.board.colored_pieces(!side, PieceType::Rook);
            let queen_orth_vulnerable = td.board.colored_pieces(!side, PieceType::Bishop) & !threats;
            let queen_diag_vulnerable = td.board.colored_pieces(!side, PieceType::Rook) & !threats;

            let mut p = pawn_attacks_setwise(td.board.colors(!side), !side) & !threats;

            // Add advanced pawn attacks to pawn offense
            p |= pawn_threats & Bitboard::LEVER_RANKS[side] & !non_pawn_threats;

            let n = knight_attacks_setwise(knight_vulnerable) & !threats;
            let b = bishop_attacks_setwise(bishop_vulnerable, occupancies) & !threats;
            let r = Bitboard::file(td.board.king_square(!side).file()) & !threats;
            let q = (rook_attacks_setwise(queen_orth_vulnerable, occupancies)
                | bishop_attacks_setwise(queen_diag_vulnerable, occupancies))
                & !threats;

            [p, n, b, r, q, Bitboard(0)]
        };

        // don't move king wall pawns
        let my_king = td.board.king_square(side);
        let wall_pawns = if Bitboard::HOME_ROWS[side].contains(my_king) {
            king_attacks(my_king) & td.board.pieces(PieceType::Pawn)
        } else {
            Bitboard(0)
        };

        for entry in self.list.iter_mut() {
            let mv = entry.mv;
            let pt = td.board.type_on(mv.from());

            entry.score = 1763 * td.quiet_history.get(threats, side, mv) / 1024
                + 1024 * td.pawn_history.get(pawn_key, td.board.moved_piece(mv), mv.to()) / 1024
                + 1614 * td.conthist(ply, 1, mv) / 1024
                + 1066 * td.conthist(ply, 2, mv) / 1024
                + 1086 * td.conthist(ply, 4, mv) / 1024
                + 1051 * td.conthist(ply, 6, mv) / 1024
                + escape[pt] * threatened[pt].contains(mv.from()) as i32
                + 10723 * td.board.checking_squares(pt).contains(mv.to()) as i32
                - 8875 * threatened[pt].contains(mv.to()) as i32
                + 3446 * offense[pt].contains(mv.to()) as i32
                - 4494 * wall_pawns.contains(mv.from()) as i32;
        }
    }
}