use std::mem;

use super::{PieceType, Square};
use crate::board::Board;

/// Represents a chess move containing the from and to squares, as well as flags for special moves.
/// The information encoded as a 16-bit integer, 6 bits for the from/to square and 4 bits for the flags.
///
/// See [Encoding Moves](https://www.chessprogramming.org/Encoding_Moves) for more information.
#[derive(Copy, Clone, Eq, Hash, PartialEq, Debug)]
pub struct Move(u16);

/// Represents a typed enumeration of move kinds, which is the 4-bit part of the encoded bit move.
/// 
/// See [From-To Based](https://www.chessprogramming.org/Encoding_Moves#From-To_Based) for more information.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
#[rustfmt::skip]
pub enum MoveKind {
    Normal            = 0b0000,
    DoublePush        = 0b0001,
    Castling          = 0b0010,

    Capture           = 0b0100,
    EnPassant         = 0b0101,

    PromotionN        = 0b1000,
    PromotionB        = 0b1001,
    PromotionR        = 0b1010,
    PromotionQ        = 0b1011,

    PromotionCaptureN = 0b1100,
    PromotionCaptureB = 0b1101,
    PromotionCaptureR = 0b1110,
    PromotionCaptureQ = 0b1111,
}

impl Move {
    pub const NULL: Self = Self(0);

    pub const fn new(from: Square, to: Square, kind: MoveKind) -> Self {
        Self(from as u16 | ((to as u16) << 6) | ((kind as u16) << 12))
    }

    pub const fn from(self) -> Square {
        Square::new((self.0 & 0b0011_1111) as u8)
    }

    pub const fn to(self) -> Square {
        Square::new(((self.0 >> 6) & 0b0011_1111) as u8)
    }

    pub const fn kind(self) -> MoveKind {
        unsafe { mem::transmute((self.0 >> 12) as u8) }
    }

    pub const fn is_present(self) -> bool {
        !self.is_null()
    }

    pub const fn is_null(self) -> bool {
        self.0 == 0
    }

    pub const fn is_quiet(self) -> bool {
        self.is_present() && !self.is_noisy()
    }

    // Sneaky bit-twidling.  If we just look at the last 3 bits (& 7), anything
    // greater than Castling is a queen push promotion or a capture.
    pub const fn is_noisy(self) -> bool {
        (self.kind() as u8 & 7) > MoveKind::Castling as u8
    }

    pub const fn is_special(self) -> bool {
        (self.kind() as u8 & 11) != 0
    }

    pub const fn is_capture(self) -> bool {
        self.0 & (1 << 14) != 0
    }

    pub const fn is_promotion(self) -> bool {
        self.0 & (1 << 15) != 0
    }

    pub const fn is_en_passant(self) -> bool {
        matches!(self.kind(), MoveKind::EnPassant)
    }

    pub fn capture_sq(self) -> Square {
        self.to() ^ (self.is_en_passant() as u8 * 8)
    }

    pub const fn is_castling(self) -> bool {
        matches!(self.kind(), MoveKind::Castling)
    }

    pub const fn is_double_push(self) -> bool {
        matches!(self.kind(), MoveKind::DoublePush)
    }

    pub const fn promo_piece_type(self) -> PieceType {
        debug_assert!(self.is_promotion());
        PieceType::new(((self.kind() as usize) & 3) + PieceType::Knight as usize)
    }

    #[cfg(feature = "syzygy")]
    pub const fn to_tb_move(self) -> crate::bindings::TbMove {
        const fn promo_bits(pt: PieceType) -> crate::bindings::TbMove {
            match pt {
                PieceType::Queen => 1,
                PieceType::Rook => 2,
                PieceType::Bishop => 3,
                PieceType::Knight => 4,
                _ => unreachable!(),
            }
        }

        let from = self.from() as u16;
        let to = self.to() as u16;

        let base = (from << 6) | to;

        if self.is_promotion() {
            let promo = promo_bits(self.promo_piece_type()) & 0x7;
            base | (promo << 12)
        } else {
            base
        }
    }

    pub fn to_uci(self, board: &Board) -> String {
        // For FRC castling moves are encoded as king capturing rook
        if board.is_frc() && self.is_castling() {
            let king_from = self.from();
            let (rook_from, _) = board.get_castling_rook(self.to());
            return format!("{king_from}{rook_from}");
        }

        let mut output = format!("{}{}", self.from(), self.to());

        if self.is_promotion() {
            match self.promo_piece_type() {
                PieceType::Knight => output.push('n'),
                PieceType::Bishop => output.push('b'),
                PieceType::Rook => output.push('r'),
                PieceType::Queen => output.push('q'),
                _ => (),
            }
        }

        output
    }
}

impl Default for Move {
    fn default() -> Self {
        Move::NULL
    }
}